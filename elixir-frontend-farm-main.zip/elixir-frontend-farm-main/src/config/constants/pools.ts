import { PoolConfig, QuoteToken, PoolCategory } from './types'

const pools: PoolConfig[] = [

]

export default pools
