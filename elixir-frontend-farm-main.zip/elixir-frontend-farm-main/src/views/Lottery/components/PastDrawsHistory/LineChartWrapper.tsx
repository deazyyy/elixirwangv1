import { Line } from 'react-chartjs-2'

export default Line
